package test;

import environnement.Environnement;
import environnement.EnvironnementPacman;
import environnement.EnvironnementSegregation;
import gui.Gui;

public class TestSegregation {
	public static void main(String[] args){

		int width, height, nbBlancs, nbNoirs;
		double seuilSatisfaction;

		width = Integer.parseInt(args[0]);
		height = Integer.parseInt(args[1]);
		nbNoirs = Integer.parseInt(args[2]);
		nbBlancs = Integer.parseInt(args[3]);
		seuilSatisfaction = ((double)Integer.parseInt(args[4]))/100;

		Environnement e = new EnvironnementSegregation(width, height,nbNoirs,nbBlancs,seuilSatisfaction);		
		Gui gui = new Gui(e);
		e.run();		
	}
}
