package test;

import agents.Agent;
import agents.AgentSegregation;
import agents.Position;
import environnement.Environnement;
import environnement.EnvironnementBille;
import environnement.EnvironnementPacman;
import environnement.EnvironnementSegregation;
import environnement.EnvironnementWator;
import gui.Gui;

public class TestWator {
	public static void main(String[] args){

		int width, height, nbRequins, nbThons;

		width = Integer.parseInt(args[0]);
		height = Integer.parseInt(args[1]);
		nbRequins = Integer.parseInt(args[2]);
		nbThons = Integer.parseInt(args[3]);

		Environnement e = new EnvironnementWator(width, height, nbRequins,nbThons);
		Gui gui = new Gui(e);
		e.run();		
	}

}
