package test;

import environnement.Environnement;
import environnement.EnvironnementPacman;
import environnement.EnvironnementWator;
import gui.Gui;

public class TestPacman {
	public static void main(String[] args){
		
		int width, height, nbProies, nbPredateurs,nbMurs;
	
		width = Integer.parseInt(args[0]);
		height = Integer.parseInt(args[1]);
		nbProies = Integer.parseInt(args[2]);
		nbPredateurs = Integer.parseInt(args[3]);
		nbMurs = Integer.parseInt(args[4]);		

			
		Environnement e = new EnvironnementPacman(width, height,nbProies,nbPredateurs,nbMurs);		
		Gui gui = new Gui(e);
		e.run();		
	}
}
