package test;

import environnement.Environnement;
import environnement.EnvironnementBille;
import environnement.EnvironnementPacman;
import gui.Gui;

public class TestBille {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int width, height, nbBilles;
		
		width = Integer.parseInt(args[0]);
		height = Integer.parseInt(args[1]);
		nbBilles = Integer.parseInt(args[2]);
			
		Environnement e = new EnvironnementBille(width, height, nbBilles);		
		Gui gui = new Gui(e);
		e.run();	

	}

}
