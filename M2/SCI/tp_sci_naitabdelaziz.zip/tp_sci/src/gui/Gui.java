package gui;

import java.awt.GridLayout;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JFrame;
import javax.swing.JPanel;

import agents.Agent;
import agents.AgentSegregation;

import environnement.Environnement;

/**
 * @author yanis
 * Classe représentant l'interface graphique de la simulation
 * Heritage de la classe Observer pour le MVC
 */
public class Gui implements Observer{

	private Environnement env;
	private JFrame fenetre;
	private JPanel panel;
	
	/**
	 * Constructeur
	 * @param e modèle associé à l'interface graphique
	 */
	public Gui(Environnement e){
		env = e;
		env.addObserver(this);
		
		fenetre = new JFrame("Simulation");
		fenetre.setSize(500, 500);
		fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(new GridLayout(env.getHeight(), env.getWidth()));
		
		for(int y=0; y<env.getHeight();y++){
			for(int x=0; x<env.getWidth();x++){
				Agent a = env.getAgent(x, y);
				if(a!=null)
					panel.add(a.draw());
				else
					panel.add(Agent.drawEmpty());				
			}
		}
		
		fenetre.add(panel);
		fenetre.setVisible(true);
	}
	
	@Override
	public void update(Observable arg0, Object arg1){
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		panel = new JPanel();
		panel.setLayout(new GridLayout(env.getHeight(), env.getWidth()));
		for(int y=0; y<env.getHeight();y++){
			for(int x=0; x<env.getWidth();x++){
				Agent a =  env.getAgent(x, y);
				if(a!=null)
					panel.add(a.draw());
				else
					panel.add(Agent.drawEmpty());				
			}
		}
		fenetre.add(panel);
		panel.updateUI();
	}
}

