package environnement;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Observable;
import java.util.Random;

import utils.PaireEntiers;

import agents.Agent;
import agents.AgentWatorThon;
import agents.Position;

/**
 * @author yanis
 * Classe abstraite représentant un environnement
 * Cette classe représente les caractéristiques communes à tous les environnement
 */
public abstract class Environnement extends Observable{

	/**
	 * Largeur et hauteur de la grille
	 */
	protected int width,height;
	/**
	 * Grille contenant les agents  
	 */
	protected Agent[][] grille;
	/**
	 * Liste des agents à faire vivre alétoirement
	 */
	protected List<Agent> agents;

	/**
	 * Constructeur
	 * @param width largeur de l'environnement
	 * @param height hauteur de l'environnement
	 */
	public Environnement(int width,int height){
		this.width = width;
		this.height= height;
		grille = new Agent[height][width];
		for(int i=0;i<height;i++){
			for(int j=0;j<width;j++){
				grille[i][j]=null;
			}
		}
		agents = new ArrayList<Agent>();   
	}

	/**
	 * Getter
	 * @return hauteur de l'environnement
	 */
	public int getHeight(){
		return height;
	}

	/**
	 * Getter
	 * @return largeur de l'environnement
	 */
	public int getWidth(){
		return width;
	}

	/**
	 * Retourne une case aléatoire libre
	 * @return position de la case
	 */
	public Position getPositionLibre(){
		int x,y;
		Random r = new Random();

		do{
			x = r.nextInt(width);
			y = r.nextInt(height);
		}
		while(estOccupee(x, y));
		Position p = new Position(x, y);
		return p;
	}

	/**
	 * Ajoute un agent dans l'environnement
	 * @param agent agent à ajouter 
	 */
	public void addAgent(Agent agent){
		int x,y;

		x= agent.getPosition().getPosX();
		y= agent.getPosition().getPosY();

		grille[y][x]=agent;
		agents.add(agent);
	}  

	/**
	 * Case occupée ou non
	 * @param x abcisse de la case
	 * @param y ordonnée de la case
	 * @return true si la case est occupée, false sinon
	 */
	public boolean estOccupee(int x, int y){
		return grille[y][x]!=null;
	}

	/**
	 * Occuper une case par un agent
	 * @param x abcisse de la case
	 * @param y ordonnée de la case
	 * @param agent agent occupant la case
	 */
	public void occuper(int x, int y,Agent agent){
		int depX = agent.getPosition().getDepX();
		int depY = agent.getPosition().getDepY();
		Position p = new Position(x, y);
		p.setDepX(depX);
		p.setDepY(depY);
		liberer(agent.getPosition().getPosX(), agent.getPosition().getPosY());
		agent.setPosition(p);
		grille[y][x]=agent;

	}

	/**
	 * Libérer la case
	 * @param x abcisse de la case
	 * @param y ordonnée de la case
	 */
	public void liberer(int x, int y){
		grille[y][x]=null;
	}    

	/**
	 * Retourne l'agent occupant une case
	 * @param x abcisse de la case
	 * @param y ordonnée de la case
	 * @return un agent
	 */
	public Agent getAgent(int x,int y){
		return grille[y][x];
	}

	/**
	 * Méthode abstraite délégant la parole à tous les agents
	 */
	public abstract void run();

	public void remove(Agent a){
		agents.remove(a);
	}

	public ArrayList<PaireEntiers> casesVoisinesLibres(int x, int y){
		ArrayList<PaireEntiers> casesVoisinesLibres = new ArrayList<PaireEntiers>();
		int x1,y1;
		for(int j=-1;j<=1;j++){
			y1 = y+j;
			if(y1 >= 0 && y1<getHeight()){
				for(int i=-1;i<=1;i++){
					x1 = x+i;
					if(x1 >=0 && x1<getWidth()){
						if(x1!=x && y1!=x){
							if(!estOccupee(x1, y1))								
								casesVoisinesLibres.add(new PaireEntiers(x1, y1));							
						}
					}
				}
			}			
		}
		return casesVoisinesLibres;
	} 

}   
