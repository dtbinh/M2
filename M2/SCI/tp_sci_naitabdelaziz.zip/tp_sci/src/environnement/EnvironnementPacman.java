package environnement;

import java.util.ArrayList;
import java.util.Collections;

import utils.PaireEntiers;

import agents.Agent;
import agents.AgentPacmanMur;
import agents.AgentPacmanPredateur;
import agents.AgentPacmanProie;
import agents.AgentSegregation;
import agents.Position;

/**
 * @author yanis
 * Classe représentant l'environnement Pacman
 */
public class EnvironnementPacman extends Environnement {

	/**
	 * Nombre de proies
	 */
	private int nbProies;
	/**
	 * Nombre de predateurs
	 */
	private int nbPredateurs;
	/**
	 * Nombre de murs
	 */
	private int nbMurs;
	
	
	/**
	 * Constructeur
	 * @param width largeur de l'environnement
	 * @param height hauteur de l'environnement 
	 * @param npro nombre de proies
	 * @param npre nombre de prédateurs
	 * @param nmu nombre de murs
	 */
	public EnvironnementPacman(int width, int height,int npro, int npre, int nmu) {
		super(width, height);
		nbProies = npro;
		nbPredateurs = npre;
		nbMurs = nmu;
		
		Position p;
		Agent a;
		
		for(int i=0;i<nbProies;i++){
			p = getPositionLibre();
			a = new AgentPacmanProie(p);
			addAgent(a);
		}
		
		for(int i=0;i<nbPredateurs;i++){
			p = getPositionLibre();
			a = new AgentPacmanPredateur(p);
			addAgent(a);
		}
		
		for(int i=0;i<nbMurs;i++){
			p = getPositionLibre();
			a = new AgentPacmanMur(p);
			addAgent(a);
		}
	}

	/* (non-Javadoc)
	 * Délégation de parole à tous les agents un par un 
	 * @see environnement.Environnement#run()
	 */
	@Override
	public void run() {
		while(true){
			
	    	for(Agent a: agents){
	    		a.vivre(this);
	    	}
	    	try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	    	this.setChanged();
	    	this.notifyObservers();
		}

	}

}
