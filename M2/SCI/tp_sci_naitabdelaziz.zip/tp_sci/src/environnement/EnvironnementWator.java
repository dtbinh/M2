package environnement;

import java.util.ArrayList;
import java.util.Collections;

import utils.PaireEntiers;

import agents.Agent;
import agents.AgentSegregation;
import agents.AgentWatorRequin;
import agents.AgentWatorThon;
import agents.Position;



/**
 * @author yanis
 * Classe représentant l'environnement de wator
 */
public class EnvironnementWator extends Environnement {

	/**
	 * Constructeur
	 * @param width largeur de l'environnement
	 * @param height hauteur de l'environnement
	 * @param nbRequin nombre de requins initial dans l'environnement
	 * @param nbThon nombre de thons initial dans l'environnement
	 */
	public EnvironnementWator(int width, int height,int nbRequin, int nbThon) {
		super(width, height);
		Position p;
		Agent a;

		for(int i=0;i<nbRequin;i++){
			p = getPositionLibre();
			a = new AgentWatorRequin(p);
			addAgent(a);
		}

		for(int i=0;i<nbThon;i++){
			p = getPositionLibre();
			a = new AgentWatorThon(p);
			addAgent(a);
		}

	}

	/* (non-Javadoc)
	 * Délégation de parole à tous les agents un par un aléatoirement
	 * @see environnement.Environnement#run()
	 */
	@Override
	public void run() {
		while(true){
			Collections.shuffle(agents);
			for(int i=0;i<agents.size();i++){
				Agent a = agents.get(i);
				a.vivre(this);
			}
			
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			this.setChanged();
			this.notifyObservers();
		}
	}
}
