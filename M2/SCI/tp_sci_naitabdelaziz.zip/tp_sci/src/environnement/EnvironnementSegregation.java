package environnement;

import java.util.Collections;

import agents.Agent;
import agents.AgentSegregation;
import agents.Position;

/**
 * @author yanis
 * Classe représentant l'environnement ségrégation
 */
public class EnvironnementSegregation extends Environnement {

	/**
	 * Constructeur
	 * @param width largeur de l'environnement
	 * @param height hauteur de l'environnement
	 * @param nbNoir nombre d'entités de couleur noir 
	 * @param nbBlanc nombre d'entités de couleur blanche
	 * @param seuilSatisfacion seuil de satisfaction 
	 */
	public EnvironnementSegregation(int width, int height,int nbNoir, int nbBlanc, double seuilSatisfacion) {
		super(width, height);
		Position p;
		Agent a;
		
		for(int i=0;i<nbNoir;i++){
			p = getPositionLibre();
			a = new AgentSegregation(p,"noir",seuilSatisfacion);
			addAgent(a);
		}
		
		for(int i=0;i<nbBlanc;i++){
			p = getPositionLibre();
			a = new AgentSegregation(p,"blanc",seuilSatisfacion);
			addAgent(a);
		}
	}

	/* (non-Javadoc)
	 * Délagation de parole aléatoire à tous les agents 
	 * @see environnement.Environnement#run()
	 */
	@Override
	public void run(){
		double avgTaux=0.0;
		while(true){
			Collections.shuffle(agents);
	    	for(Agent a: agents){
	    		a.vivre(this);
	    	}
	    	for(Agent a: agents){
	    		avgTaux += ((AgentSegregation)a).getTaux();
	    	}
	    	avgTaux = avgTaux/agents.size();
	    	System.out.println("Taux moyen = "+ avgTaux);
	    	this.setChanged();
	    	this.notifyObservers();
		}
	}
}
