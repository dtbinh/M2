package environnement;

import java.util.Collections;
import java.util.Random;

import agents.Agent;
import agents.AgentBille;
import agents.AgentSegregation;
import agents.Position;

public class EnvironnementBille extends Environnement {

    public EnvironnementBille(int width, int height, int nbBilles){
        super(width, height);
        int x, y;
        int depX, depY;
        Position p = null;
        Agent a = null;
        int deplacements[] = {0, -1, 1};

        Random r = new Random();
       

        for (int i = 0; i < nbBilles; i++) {
        	p = getPositionLibre();

            depX = deplacements[r.nextInt(3)];
            depY = deplacements[r.nextInt(3)];

            
            p.setDepX(depX);
            p.setDepY(depY);           

            a = new AgentBille(p);
            addAgent(a);           
        }
    }

    @Override
    public void run(){        		
    		while(true){
    	    	for(Agent a: agents){
    	    		a.vivre(this);
    	    	}
    	    	this.setChanged();
    	    	this.notifyObservers();
    	    	try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		}
    	
    }

}
