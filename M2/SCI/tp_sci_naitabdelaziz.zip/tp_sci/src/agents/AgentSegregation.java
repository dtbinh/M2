package agents;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.swing.JButton;

import utils.PaireEntiers;

import environnement.Environnement;

/**
 * @author yanis
 * Classe représentant un agent du système ségrégation
 */
public class AgentSegregation extends Agent{
	
	/**
	 * Type de l'agent
	 */
	private String type;
	/**
	 * Seuil de satisfaction concernant le voisinage de l'agent
	 */
	private double seuilSatisfacion;
	/**
	 * Taux de satisfaction actuel de l'agent
	 */
	private double taux;	
	
	/**
	 * Constructeur
	 * @param p position initiale de l'agent
	 * @param type type de l'agent
	 * @param seuil seuil de satisfaction de l'agent
	 */
	public AgentSegregation (Position p, String type, double seuil){
		super(p);
		this.type = type;
		this.seuilSatisfacion = seuil;
		this.taux = 0.0;
	}
	
	/* (non-Javadoc)
	 * Dessin de l'agent selon son type
	 * @see agents.Agent#draw()
	 */
	@Override
	public JButton draw(){
		JButton b = new JButton();
		
		if(type.equals("noir"))
			b.setBackground(Color.BLACK);
		else
			b.setBackground(Color.WHITE);		
		return b;
	}
	
	
	/**
	 * Getter
	 * @return type de l'agent
	 */
	public String getType(){
		return type;
	}
	
	/**
	 * Getter
	 * @return taux de satisfaction actuel de l'agent
	 */
	public double getTaux(){
		return taux;
	}

	/* (non-Javadoc)
	 * Stratégie de l'agent qui consiste à se déplacer dans une case alétoire dans l'environnement s'il n'est pas satisfait
	 * @see agents.Agent#vivre(environnement.Environnement)
	 */
	@Override
	public void vivre(Environnement e){
		int x,y,x1,y1,nbVoisins,nbVoisinsCommuns;
		AgentSegregation agentVoisin;
				
		x = position.getPosX();
		y = position.getPosY();

		nbVoisins = 0;
		nbVoisinsCommuns=0;
		
		List<PaireEntiers> casesLibres = new ArrayList<PaireEntiers>();		
		
		for(int j=-1;j<=1;j++){
			y1 = y+j;
			if(y1 >= 0 && y1<e.getHeight()){
				for(int i=-1;i<=1;i++){
					x1 = x+i;
					if(x1 >=0 && x1<e.getWidth()){
						if(x1!=x && y1!=x){
							if(e.estOccupee(x1, y1)){
								nbVoisins++;
								agentVoisin = (AgentSegregation) e.getAgent(x1, y1);
								if(this.getType().equals(agentVoisin.getType()))
									nbVoisinsCommuns++;
							}
						}
					}
				}
			}			
		}
		
		if(nbVoisins>0){
			taux = ((double)nbVoisinsCommuns/nbVoisins);
		}			
		else
			taux = 1.0;
		
		
		
		if(taux<seuilSatisfacion){	
			for(int i=0;i<e.getHeight();i++){
				for(int j=0;j<e.getWidth();j++){
					if(!e.estOccupee(j, i))
						casesLibres.add(new PaireEntiers(j,i));
				}
			}
			if(casesLibres.size()>0){
				Random r = new Random();
				int indiceCaseDestination = r.nextInt(casesLibres.size());
				e.liberer(x, y);
				e.occuper(casesLibres.get(indiceCaseDestination).x,casesLibres.get(indiceCaseDestination).y,this);
					
			}
		}
	}
}