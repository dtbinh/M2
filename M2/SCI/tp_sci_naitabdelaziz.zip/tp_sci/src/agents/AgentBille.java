package agents;

import java.awt.Color;

import javax.swing.JButton;

import environnement.Environnement;

/**
 * @author yanis
 * Classe représentant une bille
 */
public class AgentBille extends Agent {

	/**
	 * Constructeur
	 * @param p position initiale de la bille
	 */
	public AgentBille(Position p){
        super(p);
    }
    
	/* (non-Javadoc)
	 * @see agents.Agent#vivre(environnement.Environnement)
	 * Stratégie de déplacement de la bille
	 */
	@Override
    public void vivre(Environnement e){
    	int x,y,newX,newY;
    	x = position.getPosX();
    	y = position.getPosY();
    	    	
    	if(x==0)
    		position.setDepX(1);
    	if(x==e.getWidth()-1)
    		position.setDepX(-1);
    	if(y==0)
    		position.setDepY(1);
    	if(y==e.getHeight()-1)
    		position.setDepY(-1);
         
        newX = position.getPosX()+position.getDepX();
        newY = position.getPosY()+position.getDepY();
        
       /* if(e.estOccupee(newX, newY)){
        	int depX2,depY2;
        	Agent billeCollision = e.getAgent(newX, newY);
        	depX2 = billeCollision.getPosition().getDepX();
        	depY2 = billeCollision.getPosition().getDepY();
        	billeCollision.getPosition().setDepX(depX2*(-1));
        	billeCollision.getPosition().setDepY(depY2*(-1));
        	
        	getPosition().setDepX(getPosition().getDepX()*(-1));
        	getPosition().setDepY(getPosition().getDepY()*(-1));
        }*/
        
        position.setPosX(newX);
        position.setPosY(newY);
        
        e.liberer(x, y);
        e.occuper(newX, newY,this);
    }

	/* (non-Javadoc)
	 * @see agents.Agent#draw()
	 * Dessin de la bille en rouge
	 */
	@Override
	public JButton draw() {
		JButton b = new JButton();
		b.setBackground(Color.RED);
		return b;
	}   

}
