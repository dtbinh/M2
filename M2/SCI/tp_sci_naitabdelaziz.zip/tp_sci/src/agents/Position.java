package agents;

/**
 * @author yanis
 * Classe représentant une position en coordonnées cartésiennes dans l'environnement
 */
public class Position {
private int posX,posY,depX,depY;
    
    /**
     * Constructeur
     * @param x abcisse 
     * @param y ordonnée
     */
    public Position(int x, int y){
        depX=0;
        depY=0;
        posX=x;
        posY=y;
    }
    
    /**
     * Getter
     * @return abcisse
     */
    public int getPosX(){
        return posX;
    }
    
    /**
     * Getter
     * @return ordonnée
     */
    public int getPosY(){
        return posY;
    }
    
    /**
     * Setter
     * @param _posX nouvelle abcisse 
     */
    public void setPosX(int _posX){
        posX=_posX;
    }
    
    /**
     * Setter
     * @param _posY nouvelle ordonnée
     */
    public void setPosY(int _posY){
        posY=_posY;
    }
    
    public void setDepX(int x){
        depX=x;
    }
    
    public void setDepY(int y){
        depY=y;
    }
    
    public int getDepX(){
        return depX;
    }
    
    public int getDepY(){
        return depY;
    }
}
