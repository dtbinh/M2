package agents;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.JButton;

import utils.PaireEntiers;
import environnement.Environnement;

/**
 * @author yanis
 * Classe représentant un agent proie pour le pacman
 */
public class AgentPacmanProie extends Agent{
	
	/**
	 * Constructeur
	 * @param p position initiale
	 */
	public AgentPacmanProie(Position p){
		super(p);
	}
	
	

	/* (non-Javadoc)
	 * Stratégie de la proie qui consiste à fuire dans une case voisine aléatoire
	 * @see agents.Agent#vivre(environnement.Environnement)
	 */
	@Override
	public void vivre(Environnement e) {
		int x,y,x1,y1;
		AgentSegregation agentVoisin;
				
		x = position.getPosX();
		y = position.getPosY();
		
		List<PaireEntiers> casesLibres = new ArrayList<PaireEntiers>();
		
		x1 = x+1;
		if(x1<e.getWidth() && !(e.estOccupee(x1, y)))
			casesLibres.add(new PaireEntiers(x1, y));
		
		x1 = x-1;
		if(x1>=0 && !(e.estOccupee(x1, y)))
			casesLibres.add(new PaireEntiers(x1, y));
		
		y1 = y+1;
		if(y1<e.getWidth() && !(e.estOccupee(x, y1)))
			casesLibres.add(new PaireEntiers(x, y1));
		
		y1 = y-1;
		if(y1>=0 && !(e.estOccupee(x, y1)))
			casesLibres.add(new PaireEntiers(x, y1));
		
		if(casesLibres.size()>0){
			Random r = new Random();
			int indiceCaseDestination = r.nextInt(casesLibres.size());
			e.liberer(x, y);
			e.occuper(casesLibres.get(indiceCaseDestination).x,casesLibres.get(indiceCaseDestination).y,this);	
		}
	}
	
	/* (non-Javadoc)
	 * Dessin de la proie en jaune
	 * @see agents.Agent#draw()
	 */
	@Override
	public JButton draw(){
		JButton b = new JButton();
		b.setBackground(Color.YELLOW);
		return b;
	}

}
