package agents;

import java.awt.Color;

import javax.swing.JButton;

import environnement.Environnement;

/**
 * @author yanis
 * Classe représentant un mur 
 */
public class AgentPacmanMur extends Agent {
	
	/**
	 * Constructeur 
	 * @param p position du mur dans l'environnement
	 */
	public AgentPacmanMur(Position p){
		super(p);
	}

	/* (non-Javadoc)
	 * Stratégie d'un mur qui ne fait rien
	 * @see agents.Agent#vivre(environnement.Environnement)
	 */
	@Override
	public void vivre(Environnement e) {
		
	}

	/* (non-Javadoc)
	 * Dessin d'un mur
	 * @see agents.Agent#draw()
	 */
	@Override
	public JButton draw() {
		JButton b = new JButton();
		b.setBackground(Color.BLACK);
		return b;
	}

}
