package agents;

import java.awt.Color;

import javax.swing.JButton;

import environnement.Environnement;

/**
 * @author yanis
 * Classe abstraite représentant un agent
 * Cette classe regroupe les caractéristiques communes à tous les types d'agents
 */
public abstract class Agent {
	
	/**
	 * Position courante de l'agent dans l'environnement
	 */
	protected Position position;
    
       
    /**
     * Contructeur 
     * @param p position initiale de l'agent dans l'environnement
     */
    public Agent(Position p){
        position = p;
    }
    
    /**
     * Getter
     * @return position courante de l'agent 
     */
    public Position getPosition(){
        return position;
    }
    
    /**
     * Setter
     * @param p nouvelle position de l'agent
     */
    public void setPosition(Position p){
        position = p;
    }
    
    /**
     * Méthode abstraite décrivant la stratégie de l'agent
     * @param e environnement dans lequel agit l'agent
     */
    public abstract void vivre(Environnement e);
    
    /**
     * Méthode abstraite permettant de déssiner l'agent 
     * @return bouton avec une couleur spécifique à chaque type d'agent
     */
    public abstract  JButton draw();
    
    
    /**
     * Méthode statique permettant de dessiner une case vide
     * @return bouton de couleur grise
     */
    public static JButton drawEmpty(){
    	JButton b = new JButton();
		b.setBackground(Color.GRAY);
		return b;
    }
}
