package agents;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JButton;

import utils.PaireEntiers;

import environnement.Environnement;

public  class AgentWatorThon extends Agent{
	
	/**
	 * Booleen pour savoir si l'agent est encore en vie
	 */
	private boolean vivant;
	/**
	 * Période après laquelle le requin peut se reproduire
	 */
	private static int tempsGestation = 2;
	/**
	 * Nombre de cycles actuel sans repdroduction
	 */
	private int cptGestation;


	/**
	 * Constructeur
	 * @param p position initiale du thon
	 */
	public AgentWatorThon(Position p) {
		super(p);
		vivant = true;
		cptGestation = 0;
	}

	/* (non-Javadoc)
	 * Stratégie de vie du thon
	 * @see agents.Agent#vivre(environnement.Environnement)
	 */
	@Override
	public void vivre(Environnement e) {
		int x,y;
		x = getPosition().getPosX();
		y = getPosition().getPosY();
		
		if(vivant){
			Random r = new Random();
			ArrayList<PaireEntiers> casesVoisinesLibres = new ArrayList<PaireEntiers>();
			casesVoisinesLibres = e.casesVoisinesLibres(x, y);
			
			if(cptGestation>=tempsGestation){
				if(casesVoisinesLibres.size()>0){
					PaireEntiers caseNaissance = casesVoisinesLibres.get(r.nextInt(casesVoisinesLibres.size()));
					Position position = new Position(caseNaissance.x, caseNaissance.y);
					Agent agentThon = new AgentWatorThon(position);
					e.addAgent(agentThon);
					cptGestation = 0;
				}
				else
					cptGestation++;
			}
			else{
				if(casesVoisinesLibres.size()>0){
					PaireEntiers caseDeplacement = casesVoisinesLibres.get(r.nextInt(casesVoisinesLibres.size()));
					e.liberer(x, y);
					e.occuper(caseDeplacement.x,caseDeplacement.y,this);					
				}
				cptGestation++;
			}
		}
		
		else{
			e.liberer(x, y);
		}
	}

	@Override
	public JButton draw() {
		JButton b = new JButton();
		b.setBackground(Color.RED);
		return b;
	}

}
