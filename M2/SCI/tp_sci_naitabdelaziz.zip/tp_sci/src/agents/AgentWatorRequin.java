package agents;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JButton;

import utils.PaireEntiers;

import environnement.Environnement;

/**
 * @author yanis
 * Classe représentant l'entité requin
 */
public class AgentWatorRequin extends Agent{

	/**
	 * Booleen pour savoir si l'agent est encore en vie
	 */
	private boolean vivant;
	/**
	 * Période après laquelle le requin peut se reproduire
	 */
	private static int tempsGestation = 10;
	/**
	 * Période après laquelle le requin meurt s'il ne se nourrit pas
	 */
	private static int tempsMort = 3;
	/**
	 * Nombre de cycles actuel sans repdroduction
	 */
	private int cptGestation;
	/**
	 * Nombre de cycles actuel sans nourriture
	 */
	private int cptNourriture;

	/**
	 * Constructeur
	 * @param p position initiale du requin
	 */
	public AgentWatorRequin(Position p) {
		super(p);
		vivant = true;
		cptGestation = 0;
		cptNourriture = 0;
	}

	/**
	 * Liste des cases voisines dans lesquelles se trouvent un thon
	 * @param x abscisse actuelle du requin 
	 * @param y ordonnée actuelle du requin 
	 * @param e environnement dans lequel vit le requin
	 * @return liste de PaireEntiers contenant les coordonnées des cases voisines contenant un thon
	 */
	public ArrayList<PaireEntiers> voisinsThons(int x, int y,Environnement e){
		int x1,y1;
		ArrayList<PaireEntiers> voisinsThons = new ArrayList<PaireEntiers>();
		for(int j=-1;j<=1;j++){
			y1 = y+j;
			if(y1 >= 0 && y1<e.getHeight()){
				for(int i=-1;i<=1;i++){
					x1 = x+i;
					if(x1 >=0 && x1<e.getWidth()){
						if(x1!=x && y1!=x){
							if(e.estOccupee(x1, y1)){
								Agent voisin = e.getAgent(x1, y1);
								if(voisin instanceof AgentWatorThon){
									voisinsThons.add(new PaireEntiers(x1,y1));
								}
							}
						}
					}
				}
			}			
		}
		return voisinsThons;
	}

	/* (non-Javadoc)
	 * Stratégie de vie du requin
	 * @see agents.Agent#vivre(environnement.Environnement)
	 */
	@Override
	public void vivre(Environnement e) {
		int x,y;
		x = getPosition().getPosX();
		y = getPosition().getPosY();
		boolean reprod = false;

		if(vivant){
			int x1,y1;
			Random r = new Random();

			ArrayList<PaireEntiers> voisinsThons ;
			ArrayList<PaireEntiers> casesVoisinesLibres;

			casesVoisinesLibres = e.casesVoisinesLibres(x,y);			
			voisinsThons = voisinsThons(x,y,e);

			if(voisinsThons.size()>0){
				PaireEntiers thonAManger = voisinsThons.get(r.nextInt(voisinsThons.size()));
				cptNourriture = 0;


				Agent thon = e.getAgent(thonAManger.x, thonAManger.y);				
				e.remove(thon);
				e.liberer(thonAManger.x, thonAManger.x);

				e.liberer(x,y);
				e.occuper(thonAManger.x, thonAManger.y,this);

				if(cptGestation>=tempsGestation){
					casesVoisinesLibres = e.casesVoisinesLibres(thonAManger.x, thonAManger.y);

					if(casesVoisinesLibres.size()>0){					
						cptGestation =0;
						PaireEntiers positionAleatoire = casesVoisinesLibres.get(r.nextInt(casesVoisinesLibres.size()));
						Agent a = new AgentWatorRequin(new Position(positionAleatoire.x, positionAleatoire.y));
						e.addAgent(a);
						reprod = true;
					}						
				}
			}

			else{
				cptNourriture++;
				if(cptNourriture>=tempsMort)
					vivant = false;
				else{
					if(casesVoisinesLibres.size()>0){ 
						PaireEntiers positionAleatoire = casesVoisinesLibres.get(r.nextInt(casesVoisinesLibres.size()));
						if(cptGestation>=tempsGestation){
							cptGestation =0;							
							Agent a = new AgentWatorRequin(new Position(positionAleatoire.x, positionAleatoire.y));
							e.addAgent(a);
							reprod = true;
						}	
						else{
							e.liberer(x, y);
							e.occuper(positionAleatoire.x, positionAleatoire.y,this);
						}
					}						
				}				
			}
			if(!reprod)
				cptGestation++;
		}

		else{
			e.liberer(x, y);
			e.remove(this);
		}
	}

	/* (non-Javadoc)
	 * Dessin du requin en bleu
	 * @see agents.Agent#draw()
	 */
	@Override
	public JButton draw() {
		JButton b = new JButton();
		b.setBackground(Color.BLUE);
		return b;
	}

}
