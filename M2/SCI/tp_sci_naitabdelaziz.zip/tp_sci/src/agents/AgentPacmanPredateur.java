package agents;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JButton;

import utils.PaireEntiers;

import environnement.Environnement;

/**
 * @author yanis
 * Classe représentant un agent prédateur pour le pacman
 */
public class AgentPacmanPredateur extends Agent{
	/**
	 * Tableau contenant les distances de toutes les cases vides pour une proie donnée
	 */
	private int dijkstra[][];


	/**
	 * Constructeur
	 * @param p position initiale du prédateur
	 */
	public AgentPacmanPredateur(Position p){
		super(p);		
	}


	/* (non-Javadoc)
	 * Stratégie du prédateur
	 * Le prédateur prend en chasse une proie aléatoire et emprunte le plus court chemin pour suivre celle-ci
	 * @see agents.Agent#vivre(environnement.Environnement)
	 */
	@Override
	public void vivre(Environnement e) {
		int x,y;
		x = getPosition().getPosX();
		y = getPosition().getPosY();

		dijkstra = new int[e.getHeight()][e.getWidth()];
		ArrayList<PaireEntiers> proies = new ArrayList<PaireEntiers>();
		for(int i=0;i<e.getHeight();i++){
			for(int j=0;j<e.getWidth();j++){
				dijkstra[i][j] = Integer.MAX_VALUE;
				if(e.estOccupee(j, i)){
					if(e.getAgent(j, i) instanceof AgentPacmanProie)
						proies.add(new PaireEntiers(j,i));
				}
			}
		}
		Random r = new Random();
		int indiceProieAleatoire;
		indiceProieAleatoire = r.nextInt(proies.size());

		dijkstra[proies.get(indiceProieAleatoire).y][proies.get(indiceProieAleatoire).x]=0;
		Dijkstra(proies.get(indiceProieAleatoire).x,proies.get(indiceProieAleatoire).y,e);	

		int x1,y1,newPosX = -1,newPosY = -1,distance;
		distance = Integer.MAX_VALUE;

		x1 = x+1;		
		if(x1<e.getWidth() && !(e.estOccupee(x1, y))){
			if(dijkstra[y][x1]<distance){
				distance = dijkstra[y][x1];
				newPosX = x1;
				newPosY = y;
			}			
		}

		x1 = x-1;		
		if(x1>=0 && !(e.estOccupee(x1, y))){
			if(dijkstra[y][x1]<distance){
				distance = dijkstra[y][x1];
				newPosX = x1;
				newPosY = y;
			}			
		}

		y1 = y+1;		
		if(y1<e.getHeight() && !(e.estOccupee(x, y1))){
			if(dijkstra[y1][x]<distance){
				distance = dijkstra[y1][x];
				newPosX = x;
				newPosY = y1;
			}			
		}

		y1 = y-1;		
		if(y1>=0 && !(e.estOccupee(x, y1))){
			if(dijkstra[y1][x]<distance){
				distance = dijkstra[y1][x];
				newPosX = x;
				newPosY = y1;
			}			
		}
		if(newPosX!=-1 && newPosY!=-1){
			e.liberer(getPosition().getPosX(), getPosition().getPosY());
			e.occuper(newPosX,newPosY,this);	
		}
	}

	/**
	 * Méthode permettant de calculer la plus courte distance de toutes les autres cases par rapport à une proie 
	 * @param x abscisse de la proie
	 * @param y ordonnée de la proie
	 * @param e environnement 
	 */
	public void Dijkstra(int x,int y, Environnement e){
		int xsuiv,ysuiv;

		xsuiv = x+1;
		ysuiv = y;

		if(xsuiv<e.getWidth() && !(e.estOccupee(xsuiv, ysuiv))){
			if(dijkstra[ysuiv][xsuiv]>dijkstra[y][x]+1){
				dijkstra[ysuiv][xsuiv]=dijkstra[y][x]+1;
				Dijkstra(xsuiv,ysuiv,e);
			}				
		}

		xsuiv = x-1;
		ysuiv = y;

		if(xsuiv>=0 && !(e.estOccupee(xsuiv, ysuiv))){
			if(dijkstra[ysuiv][xsuiv]>dijkstra[y][x]+1){
				dijkstra[ysuiv][xsuiv]=dijkstra[y][x]+1;
				Dijkstra(xsuiv,ysuiv,e);
			}
		}

		xsuiv = x;
		ysuiv = y+1;

		if(ysuiv<e.getHeight() && !(e.estOccupee(xsuiv, ysuiv))){
			if(dijkstra[ysuiv][xsuiv]>dijkstra[y][x]+1){
				dijkstra[ysuiv][xsuiv]=dijkstra[y][x]+1;
				Dijkstra(xsuiv,ysuiv,e);
			}
		}

		xsuiv = x;
		ysuiv = y-1;

		if(ysuiv>=0 && !(e.estOccupee(xsuiv, ysuiv))){
			if(dijkstra[ysuiv][xsuiv]>dijkstra[y][x]+1){
				dijkstra[ysuiv][xsuiv]=dijkstra[y][x]+1;
				Dijkstra(xsuiv,ysuiv,e);
			}
		}
	}

	/* (non-Javadoc)
	 * Dessin du prédateur en rouge
	 * @see agents.Agent#draw()
	 */
	@Override
	public JButton draw(){
		JButton b = new JButton();
		b.setBackground(Color.RED);
		return b;
	}
}
