package utils;

public class PaireEntiers {
	public int x,y;
		
	public PaireEntiers(int x,int y){
		this.x=x;
		this.y=y;
	} 
}
