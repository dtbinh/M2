#ifndef NURBS_H
#define NURBS_H

#include <vector>
#include "Vector2.h"

class Nurbs{
    int degre;
    int nbPoints;

    double xmax,ymax;

    std::vector<double> _knot;
    std::vector<Vector2> _controle;
    std::vector<double> _ordonnee;


    public:

    Nurbs();
    virtual ~Nurbs();
    void initialize(int _nbPoints , int _degre);
    double evalue(int k, int p, double t);
    void drawN(int k, int p);
    void drawNurbs(int p);
    void addControlPoint(Vector2 p);
    void drawControlPoints()const;

};

#endif // NURBS_H
