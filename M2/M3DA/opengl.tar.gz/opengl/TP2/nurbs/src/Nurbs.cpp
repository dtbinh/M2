#include <stdlib.h>
#include <iostream>
#include "Nurbs.h"
#include "Vector2.h"
#include <GL/gl.h>

Nurbs::Nurbs(){

}

Nurbs::~Nurbs(){

}

void Nurbs::initialize(int _nbPoints , int _degre){
    this->degre = _degre;
    this->nbPoints = _nbPoints;
    ymax = -1;
    xmax = -1;

    this->_knot.clear();
    this->_ordonnee.clear();
    this->_controle.clear();

    for(unsigned int i=0;i<_nbPoints+_degre+1;i++){
        this->_knot.push_back(i+1);
    }

}

double Nurbs::evalue(int k, int p, double t){
    if(p==0){
        if(t >= _knot.at(k) && t<_knot.at(k+1))
            return 1;
        else
            return 0;
    }
    else{
        return ((t-_knot.at(k))/(_knot.at(k+p)-_knot.at(k)))*(evalue(k,p-1,t))+(((_knot.at(p+k+1)-t)/(_knot.at(p+k+1)-_knot.at(k+1)))*evalue(k+1,p-1,t));
    }
}

void Nurbs::drawN(int k, int p){

    double n;

    for(int i=0;i<_knot.size();i++){
        n = evalue(k,p,_knot.at(i));
        _ordonnee.push_back(n);
        if(n>ymax)
            ymax = n;
        if(_knot.at(i)>xmax)
            xmax = _knot.at(i);
    }


    glPushMatrix();

    glColor3f(1,0,0);
    glLineWidth(3);
    glColor3f(0,1,0);

    glOrtho(-1,xmax*2+1,-1,ymax+1,-1,1);

    glBegin(GL_LINE_STRIP);
    for(int i=0;i<_knot.size();i++){
        glVertex2f(_knot.at(i),_ordonnee.at(i));
    }
    glEnd();

    glPopMatrix();

}

void Nurbs::drawNurbs(int p){
    for(int i = 0; i<_knot.size()-2;i++){
        Nurbs n;
        n.initialize(nbPoints,degre);
        n.drawN(i,p);
    }
}

void Nurbs::addControlPoint(Vector2 p){
    _controle.push_back(p);
}

void Nurbs::drawControlPoints()const{
    glPushMatrix();



    glColor3f(1,0,0);

    glOrtho(-10,10,-10,10+1,-1,1);

    glBegin(GL_POINTS);
    for(int i=0;i<_knot.size();i++){
        glVertex2f(_controle.at(i).x,_controle.at(i).y);
    }
    glEnd();

    glPopMatrix();
}
